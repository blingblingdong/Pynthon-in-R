userInput1 = input("你的名字是：")
print("使用者： 我的名字是",userInput1)
print("機器人：",userInput1,"這個名字真好聽，很高興跟你聊天")

userInput2 = input("你今年幾歲：")
doubleAge = int(userInput2)*2
print("使用者： 我今年",userInput2)
print("機器人：",doubleAge,"騙人！")
print("機器人：你的歲數的兩倍是",v,"也太老了吧")

print("機器人：偵查到有政治駭客入侵\n救救我\n我\n啊")
userInput5 = input("按1樂捐1元，按2樂捐2千，按3與對方進行更多對話")
print("你不會以為按了有用吧")

print("---------------------------------------")
print("--------------------------------")
print("-------------------")
print("-----------")
print("-----")
print("--")
print("-")

print("你好，我是政治木馬病毒，你現在所說的一切都會變成十年後的會考考題")
userInput5 = input("你是台灣人嗎？")
print(f"使用者：我{userInput5}")
print("不論你認同什麼，都歡迎加入先祖老蔣的抗戰行列")
print("呵呵呵")
print("你問我是誰")
print("我是榮譽國民")

userInput6 = input("你支持年金改革嗎？")
print("我是不知道啦")
print("我可不是法律上的人")
print("才不會告訴你")

userInput7 = input("你真的想知道？")
print(f"使用者：我{userInput7}")
print("誒都")
print("正在導入政治理論模型")
print("外交關係實務")
print("郭台銘的名弔")
print("蔡英文的論文")
print("lin bay好油的聊天紀錄")
print(".....\n....\n...\n..\n.")
print("""\

                                       ._ o o
                                       \_`-)|_
                                    ,""       \ 
                                  ,"馬英參戰  ಠ ಠ. 
                                ," 你   ,-\__    `.
                              ,"       /     `--._;)
                            ,"    以為/
                          ,"   有酒？/


                    """)
                    
                    
print("One Peice是真實存在的！")
print("---------------------------------------")
print("--------------------------------")
print("-------------------")
print("-----------")
print("-----")
print("--")
print("-")
print("(系統已恢復連線)")

userInput8 = input("問點別的問題？")
print("使用者：{userInput8}")
print("機器人：這個嘛，\n痾，\n誒")
print("as you know , I am pre-trained robot ")
print("I can't give you instant response ")
print("but you can make a wish")
print("sent your instagram account to me")
userInput9 = input("你的ig？")
print("I see")
print("查看中")
print(".....\n....\n...\n..\n.")
print(f"你的名字是{userInput1}，你虛度的歲月是{userInput2}年\n啊是一輩子呢")
print("哈哈")
print("這個驚喜又快又精準吧")
print("你的個資我已經從你的ig掌握啦")


userInput3 = input("你打算幾點睡覺：")
print(f"使用者： 我打算{userInput3}點睡")
print("機器人：喔是喔，不過我要睡了\n超過五點不要再打給我")
print("因為\n我\n睡\n啦")
print("(機器人助理已離線)")

